
public interface booleanExpression {

public boolean EvaluateExpression(String s);
}
